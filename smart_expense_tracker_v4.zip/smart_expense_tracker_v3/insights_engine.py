import streamlit as st

def show_insights():
    st.header("🤖 Smart Insights (LLM)")
    st.info("Coming soon: AI-powered savings advice based on your income & expenses!")